LIFE OS — Mobile PWA

Файлдар:
- index.html — қолданбаның интерфейсі
- manifest.webmanifest — телефонға орнату параметрлері
- service-worker.js — офлайн кэш
- icons/ — қолданба белгішелері

Орнату:
1) Осы буманы HTTPS қолдайтын хостингке толық жүктеңіз (мысалы, GitHub Pages немесе Netlify).
2) Сайтты телефон браузерінде ашыңыз.
3) iPhone: Safari → Share → Add to Home Screen.
4) Android: Chrome → Install app / Add to Home screen.

Ескерту:
- PWA-ны телефонға орнату үшін сайт HTTPS арқылы жариялануы керек (localhost-тан басқа).
- Деректер IndexedDB-де сол браузер/құрылғыда сақталады; автоматты бұлттық синхрондау жоқ.
- Бұл — веб-қолданба ретінде орнатылатын нұсқа, App Store/Google Play-ге жарияланған native app емес.
